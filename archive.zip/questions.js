const questionsData = {

    "Mathematics": [

        {
            question: "A trader buys an article for KSh 2,400 and sells it at a profit of 15%. What is the selling price?",
            options: [
                "KSh 2,640",
                "KSh 2,760",
                "KSh 2,820",
                "KSh 2,940"
            ],
            correct: "KSh 2,760"
        },

        {
            question: "Solve the equation 2(3x - 4) = 5x + 7.",
            options: [
                "x = 11",
                "x = 13",
                "x = 15",
                "x = 17"
            ],
            correct: "x = 15"
        },

        {
            question: "The first three terms of an arithmetic progression are 7, 12 and 17. What is the 20th term?",
            options: [
                "97",
                "102",
                "107",
                "112"
            ],
            correct: "102"
        },

        {
            question: "A quantity increases from 80 to 104. What is the percentage increase?",
            options: [
                "20%",
                "24%",
                "30%",
                "32%"
            ],
            correct: "30%"
        },

        {
            question: "The angles of a triangle are in the ratio 2 : 3 : 4. What is the size of the largest angle?",
            options: [
                "60°",
                "70°",
                "80°",
                "90°"
            ],
            correct: "80°"
        },

        {
            question: "A rectangular garden measures 24 m by 15 m. A path of uniform width 2 m is constructed inside the garden along all four sides. What is the area of the remaining garden?",
            options: [
                "220 m²",
                "240 m²",
                "280 m²",
                "300 m²"
            ],
            correct: "220 m²"
        },

        {
            question: "If 3x - 2y = 7 and x + y = 5, what is the value of x?",
            options: [
                "2",
                "3",
                "4",
                "5"
            ],
            correct: "17 / 5"
        },

        {
            question: "The mean of five numbers is 18. Four of the numbers are 12, 15, 21 and 24. Find the fifth number.",
            options: [
                "16",
                "18",
                "20",
                "22"
            ],
            correct: "18"
        },

        {
            question: "A bag contains 5 red balls, 3 blue balls and 2 green balls. One ball is selected at random. What is the probability of selecting a blue ball?",
            options: [
                "1/5",
                "3/10",
                "1/3",
                "2/5"
            ],
            correct: "3/10"
        },

        {
            question: "A car travels 180 km in 2 hours 15 minutes. What is its average speed in km/h?",
            options: [
                "72 km/h",
                "75 km/h",
                "80 km/h",
                "90 km/h"
            ],
            correct: "80 km/h"
        },

        {
            question: "The bearing of B from A is 065°. What is the bearing of A from B?",
            options: [
                "115°",
                "245°",
                "295°",
                "305°"
            ],
            correct: "245°"
        },

        {
            question: "A ladder 10 m long rests against a vertical wall. Its foot is 6 m from the wall. How high up the wall does the ladder reach?",
            options: [
                "6 m",
                "7 m",
                "8 m",
                "9 m"
            ],
            correct: "8 m"
        },

        {
            question: "Simplify: (x² - 9) / (x - 3), where x ≠ 3.",
            options: [
                "x - 3",
                "x + 3",
                "x² + 3",
                "x² - 3"
            ],
            correct: "x + 3"
        },

        {
            question: "A cylinder has radius 7 cm and height 10 cm. Using π = 22/7, find its volume.",
            options: [
                "1,320 cm³",
                "1,400 cm³",
                "1,540 cm³",
                "1,680 cm³"
            ],
            correct: "1,540 cm³"
        },

        {
            question: "The gradient of a straight line passing through the points (2, 5) and (6, 17) is:",
            options: [
                "2",
                "3",
                "4",
                "5"
            ],
            correct: "3"
        },

        {
            question: "If log₁₀ x = 2.5, which of the following represents x?",
            options: [
                "25",
                "100",
                "250",
                "10√10"
            ],
            correct: "10√10"
        },

        {
            question: "A map has a scale of 1 : 50,000. Two towns are 7.2 cm apart on the map. What is their actual distance?",
            options: [
                "2.4 km",
                "3.0 km",
                "3.6 km",
                "4.2 km"
            ],
            correct: "3.6 km"
        },

        {
            question: "The exterior angle of a regular polygon is 24°. How many sides does the polygon have?",
            options: [
                "12",
                "15",
                "18",
                "20"
            ],
            correct: "15"
        },

        {
            question: "A man deposits KSh 20,000 in an account earning simple interest at 8% per annum. How much interest will he earn after 3 years?",
            options: [
                "KSh 4,800",
                "KSh 5,200",
                "KSh 5,600",
                "KSh 6,000"
            ],
            correct: "KSh 4,800"
        },

        {
            question: "The probability that a student passes Mathematics is 0.7 and the probability that the student passes Physics is 0.6. Assuming the events are independent, what is the probability that the student passes both subjects?",
            options: [
                "0.13",
                "0.42",
                "0.60",
                "0.76"
            ],
            correct: "0.42"
        }

    ],


    "English": [],

    "Kiswahili": [],

    "Physics": [],

    "Chemistry": [],

    "Biology": [],

    "Geography": [],

    "History": [],

    "CRE": []

};