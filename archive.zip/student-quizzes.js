document.addEventListener("DOMContentLoaded", () => {

    const QUESTIONS_PER_QUIZ = 10;
    const XP_PER_CORRECT = 10;

    let currentSubject = "";
    let currentQuestions = [];
    let currentQuestionIndex = 0;
    let score = 0;
    let earnedXP = 0;
    let answered = false;

    const subjectGrid = document.getElementById("subjectGrid");
    const selectionArea = document.querySelector(".quiz-selection");
    const quizArea = document.getElementById("quizArea");
    const resultArea = document.getElementById("quizResult");

    let totalXP = Number(localStorage.getItem("studentXP")) || 0;


    /* ===============================
       SHUFFLE
    =============================== */

    function shuffle(array) {
        const copy = [...array];

        for (let i = copy.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));

            [copy[i], copy[j]] =
            [copy[j], copy[i]];
        }

        return copy;
    }


    /* ===============================
       XP DISPLAY
    =============================== */

    function updateXPDisplay() {

        const level = Math.floor(totalXP / 500) + 1;
        const progress = (totalXP % 500) / 500 * 100;

        const xpAmount =
            document.getElementById("xpAmount");

        const xpBar =
            document.getElementById("xpBar");

        const levelName =
            document.getElementById("levelName");

        const xpProgress =
            document.getElementById("xpProgress");

        if (xpAmount)
            xpAmount.textContent = totalXP;

        if (xpBar)
            xpBar.style.width = progress + "%";

        if (levelName)
            levelName.textContent =
                `Level ${level} Scholar`;

        if (xpProgress)
            xpProgress.textContent =
                `${totalXP % 500} / 500 XP`;
    }


    /* ===============================
       SUBJECTS
    =============================== */

    const subjects = [

        {
            name: "Mathematics",
            icon: "∑",
            description:
                "Algebra, geometry, statistics and problem solving."
        },

        {
            name: "English",
            icon: "Aa",
            description:
                "Grammar, comprehension, writing and literature."
        },

        {
            name: "Kiswahili",
            icon: "文",
            description:
                "Sarufi, fasihi, lugha na ufahamu."
        },

        {
            name: "Physics",
            icon: "⚡",
            description:
                "Motion, forces, energy, electricity and waves."
        },

        {
            name: "Chemistry",
            icon: "⚗",
            description:
                "Atoms, reactions, equations and matter."
        },

        {
            name: "Biology",
            icon: "🧬",
            description:
                "Cells, genetics, ecology and human biology."
        },

        {
            name: "Geography",
            icon: "🌍",
            description:
                "Maps, climate, landforms and environment."
        },

        {
            name: "History",
            icon: "🏛",
            description:
                "Historical events, societies and civilizations."
        },

        {
            name: "CRE",
            icon: "✝",
            description:
                "Christian Religious Education."
        }

    ];


    function createSubjects() {

        if (!subjectGrid) return;

        subjectGrid.innerHTML = "";

        subjects.forEach(subject => {

            const card =
                document.createElement("button");

            card.type = "button";

            card.className =
                "subject-card";

            card.innerHTML = `

                <div class="subject-content">

                    <div class="subject-icon">
                        ${subject.icon}
                    </div>

                    <h3>
                        ${subject.name}
                    </h3>

                    <p>
                        ${subject.description}
                    </p>

                </div>

                <span class="count">
                    Questions →
                </span>

            `;

            card.addEventListener(
                "click",
                () => startQuiz(subject.name)
            );

            subjectGrid.appendChild(card);

        });
    }


    /* ===============================
       START QUIZ
    =============================== */

    function startQuiz(subject) {

        console.log("Starting quiz:", subject);

        if (typeof questionsData === "undefined") {

            alert(
                "ERROR: questions.js was not loaded."
            );

            return;
        }

        console.log(
            "Available subjects:",
            Object.keys(questionsData)
        );


        const subjectQuestions =
            questionsData[subject];


        if (!subjectQuestions) {

            alert(
                `No questions found for ${subject}.`
            );

            return;
        }


        if (subjectQuestions.length === 0) {

            alert(
                `${subject} currently has no questions.`
            );

            return;
        }


        currentSubject = subject;

        currentQuestionIndex = 0;

        score = 0;

        earnedXP = 0;

        answered = false;


        currentQuestions =
            shuffle(subjectQuestions)
            .slice(
                0,
                Math.min(
                    QUESTIONS_PER_QUIZ,
                    subjectQuestions.length
                )
            );


        selectionArea.classList.add("hidden");

        resultArea.classList.add("hidden");

        quizArea.classList.remove("hidden");


        const currentSubjectElement =
            document.getElementById("currentSubject");

        if (currentSubjectElement) {
            currentSubjectElement.textContent =
                subject;
        }


        showQuestion();
    }


    /* ===============================
       SHOW QUESTION
    =============================== */

    function showQuestion() {

        answered = false;

        const question =
            currentQuestions[currentQuestionIndex];


        if (!question) {

            finishQuiz();

            return;
        }


        const questionText =
            document.getElementById("questionText");

        const questionTopic =
            document.getElementById("questionTopic");

        const questionNumber =
            document.getElementById("questionNumber");

        const questionCounter =
            document.getElementById("questionCounter");

        const answerOptions =
            document.getElementById("answerOptions");

        const nextButton =
            document.getElementById("nextButton");


        if (questionTopic)
            questionTopic.textContent =
                currentSubject;


        if (questionNumber)
            questionNumber.textContent =
                String(
                    currentQuestionIndex + 1
                ).padStart(2, "0");


        if (questionCounter)
            questionCounter.textContent =
                `Question ${
                    currentQuestionIndex + 1
                } of ${
                    currentQuestions.length
                }`;


        if (questionText)
            questionText.textContent =
                question.question;


        answerOptions.innerHTML = "";


        const shuffledOptions =
            shuffle(question.options);


        shuffledOptions.forEach(
            (answer, index) => {

                const button =
                    document.createElement("button");

                button.type = "button";

                button.className =
                    "answer-button";


                button.innerHTML = `

                    <span class="answer-letter">
                        ${String.fromCharCode(
                            65 + index
                        )}
                    </span>

                    <span>
                        ${answer}
                    </span>

                `;


                button.addEventListener(
                    "click",
                    () => {

                        selectAnswer(
                            button,
                            answer,
                            question.correct
                        );

                    }
                );


                answerOptions.appendChild(button);

            }
        );


        nextButton.disabled = true;

        nextButton.classList.remove("ready");

        nextButton.textContent =
            "Choose an answer";
    }


    /* ===============================
       SELECT ANSWER
    =============================== */

    function selectAnswer(
        selectedButton,
        selectedAnswer,
        correctAnswer
    ) {

        if (answered) return;

        answered = true;


        const buttons =
            document.querySelectorAll(
                ".answer-button"
            );


        buttons.forEach(button => {
            button.disabled = true;
        });


        if (selectedAnswer === correctAnswer) {

            selectedButton.classList.add(
                "correct"
            );

            score++;

            earnedXP += XP_PER_CORRECT;

        } else {

            selectedButton.classList.add(
                "wrong"
            );


            buttons.forEach(button => {

                const answerText =
                    button
                    .querySelector(
                        "span:last-child"
                    );


                if (
                    answerText &&
                    answerText.textContent.trim()
                    === correctAnswer
                ) {

                    button.classList.add(
                        "correct"
                    );

                }

            });

        }


        const nextButton =
            document.getElementById(
                "nextButton"
            );


        nextButton.disabled = false;

        nextButton.classList.add("ready");


        if (
            currentQuestionIndex
            === currentQuestions.length - 1
        ) {

            nextButton.textContent =
                "Finish Quiz →";

        } else {

            nextButton.textContent =
                "Next Question →";

        }


        const liveXP =
            document.getElementById("liveXP");

        if (liveXP)
            liveXP.textContent =
                earnedXP;
    }


    /* ===============================
       NEXT QUESTION
    =============================== */

    const nextButton =
        document.getElementById("nextButton");


    if (nextButton) {

        nextButton.addEventListener(
            "click",
            () => {

                if (!answered) return;


                if (
                    currentQuestionIndex
                    <
                    currentQuestions.length - 1
                ) {

                    currentQuestionIndex++;

                    showQuestion();

                } else {

                    finishQuiz();

                }

            }
        );

    }


    /* ===============================
       FINISH QUIZ
    =============================== */

    function finishQuiz() {

        totalXP += earnedXP;

        localStorage.setItem(
            "studentXP",
            totalXP
        );


        quizArea.classList.add("hidden");

        resultArea.classList.remove("hidden");


        const correctAnswers =
            document.getElementById(
                "correctAnswers"
            );

        const earnedXPElement =
            document.getElementById(
                "earnedXP"
            );

        const accuracy =
            document.getElementById(
                "accuracy"
            );


        if (correctAnswers)
            correctAnswers.textContent =
                score;


        if (earnedXPElement)
            earnedXPElement.textContent =
                `+${earnedXP}`;


        if (accuracy) {

            const percentage =
                Math.round(
                    (score /
                    currentQuestions.length)
                    * 100
                );

            accuracy.textContent =
                `${percentage}%`;

        }


        updateXPDisplay();
    }


    /* ===============================
       BACK BUTTON
    =============================== */

    const backButton =
        document.getElementById(
            "backButton"
        );


    if (backButton) {

        backButton.addEventListener(
            "click",
            () => {

                quizArea.classList.add(
                    "hidden"
                );

                resultArea.classList.add(
                    "hidden"
                );

                selectionArea.classList.remove(
                    "hidden"
                );

            }
        );

    }


    /* ===============================
       PLAY AGAIN
    =============================== */

    const playAgain =
        document.getElementById(
            "playAgain"
        );


    if (playAgain) {

        playAgain.addEventListener(
            "click",
            () => {

                resultArea.classList.add(
                    "hidden"
                );

                startQuiz(currentSubject);

            }
        );

    }


    /* ===============================
       CHOOSE SUBJECT
    =============================== */

    const chooseSubject =
        document.getElementById(
            "chooseSubject"
        );


    if (chooseSubject) {

        chooseSubject.addEventListener(
            "click",
            () => {

                resultArea.classList.add(
                    "hidden"
                );

                selectionArea.classList.remove(
                    "hidden"
                );

            }
        );

    }


    /* ===============================
       INITIALIZE
    =============================== */

    createSubjects();

    updateXPDisplay();

});